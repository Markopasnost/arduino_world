<?php
// Указываем, что скрипт возвращает JSON
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type');

// ==========================================
// НАСТРОЙКИ ВАШЕЙ БАЗЫ ДАННЫХ С ХОСТИНГА
// ==========================================
$host = 'localhost';      // Обычно localhost, но иногда хостинг выдает другой адрес
$db   = 'имя_вашей_базы'; // Например: u12345_robobase
$user = 'имя_пользователя';// Например: u12345_user
$pass = 'ваш_пароль';     // Пароль от пользователя БД
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    echo json_encode(['error' => 'Ошибка подключения к БД. Проверьте логин и пароль.']);
    exit;
}

$method = $_SERVER['REQUEST_METHOD'];

// Если HTML запрашивает сообщения (GET-запрос)
if ($method === 'GET') {
    // Получаем сообщения (новые сверху)
    $stmt = $pdo->query("SELECT author, text, DATE_FORMAT(created_at, '%d.%m.%Y %H:%i') as date FROM posts ORDER BY id DESC");
    $posts = $stmt->fetchAll();
    echo json_encode($posts);
} 
// Если HTML отправляет новое сообщение (POST-запрос)
elseif ($method === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!empty($input['author']) && !empty($input['text'])) {
        $stmt = $pdo->prepare("INSERT INTO posts (author, text) VALUES (?, ?)");
        $stmt->execute([$input['author'], $input['text']]);
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Пустые поля']);
    }
}
?>