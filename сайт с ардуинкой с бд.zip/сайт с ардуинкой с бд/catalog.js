document.addEventListener('DOMContentLoaded', () => {
    fetch('http://localhost:3000/api/components')
        .then(response => response.json())
        .then(data => {
            const PRO_SENSOR_IDS = new Set([
                'ms5611', 'sdp810', 'mics2714', 'fxos8700cq', 'lps22hb',
                'max44009', 'as7341', 'mlx90640', 'tmd2772', 'ina260'
            ]);
            const categoryToMenu = {
                'arduino': 'menu-arduino',
                'arduino_shields': 'menu-shields',
                'boards3d': 'menu-cnc',
                'drivers': 'menu-drivers',
                'esp32': 'menu-esp32',
                'esp8266': 'menu-esp8266',
                'esp_shields': 'menu-espshields',
                'nema': 'menu-nema',
                'orangepi': 'menu-opi',
                'raspberrypi': 'menu-rpi',
                'servo': 'menu-servo'
            };
            const grouped = {};
            data.forEach(item => {
                if (!grouped[item.category]) grouped[item.category] = [];
                grouped[item.category].push(item);
            });
            function renderList(menuId, items) {
                const list = document.getElementById(menuId);
                if (!list || !items) return;
                const fragment = document.createDocumentFragment();
                items.forEach(item => {
                    const li = document.createElement('li');
                    const a = document.createElement('a');
                    a.href = '#';
                    a.setAttribute('data-board', item.id);
                    a.textContent = item.name;
                    a.title = item.name;
                    li.appendChild(a);
                    fragment.appendChild(li);
                });
                list.replaceChildren(fragment);
                const details = list.closest('details');
                if (details) details.setAttribute('data-count', items.length);
            }
            Object.keys(categoryToMenu).forEach(dbCategory => {
                renderList(categoryToMenu[dbCategory], grouped[dbCategory]);
            });
            if (grouped['sensors']) {
                const basicSensors = grouped['sensors'].filter(s => !PRO_SENSOR_IDS.has(s.id));
                const proSensors = grouped['sensors'].filter(s => PRO_SENSOR_IDS.has(s.id));
                renderList('menu-sensors', basicSensors);
                renderList('menu-sensors-pro', proSensors);
            }
        })
        .catch(err => console.error('Ошибка загрузки каталога:', err));
});