const sqlite3 = require('sqlite3').verbose();
const fs = require('fs');
const vm = require('vm');

const filesToRead = [
    { file: 'arduino.js', varName: 'arduinoData', category: 'arduino' },
    { file: 'arduinoshields.js', varName: 'arduinoshieldsData', category: 'arduino_shields' },
    { file: 'boards3d.js', varName: 'boards3dData', category: 'boards3d' },
    { file: 'drivers.js', varName: 'driversData', category: 'drivers' },
    { file: 'esp32.js', varName: 'esp32Data', category: 'esp32' },
    { file: 'ESP8266.js', varName: 'ESP8266Data', category: 'esp8266' },
    { file: 'ESPSHIELDS.js', varName: 'ESPSHIELDSData', category: 'esp_shields' },
    { file: 'NEMA.js', varName: 'NEMAData', category: 'nema' },
    { file: 'orangepi.js', varName: 'orangepiData', category: 'orangepi' },
    { file: 'RASPBERRYPI.js', varName: 'RASPBERRYPIData', category: 'raspberrypi' },
    { file: 'sensor.js', varName: 'sensorData', category: 'sensors' },
    { file: 'servo.js', varName: 'servoData', category: 'servo' }
];

if (fs.existsSync('./arduino_world.db')) {
    fs.unlinkSync('./arduino_world.db');
    console.log('🗑️ Старая база удалена.');
}

const db = new sqlite3.Database('./arduino_world.db');

db.serialize(() => {
    db.run(`
        CREATE TABLE Components (
            id TEXT PRIMARY KEY,
            category TEXT,
            name TEXT,
            image TEXT,
            desc TEXT,
            mcu TEXT,
            freq TEXT,
            mem TEXT,
            conn TEXT,
            code TEXT
        )
    `);

    console.log('✅ Таблица Components создана. Начинаем перенос...');

    let totalAdded = 0;

    filesToRead.forEach(({ file, varName, category }) => {
        if (!fs.existsSync(file)) {
            console.log(`⚠️ Файл ${file} не найден. Пропускаем.`);
            return;
        }

        try {
            const code = fs.readFileSync(file, 'utf8');
            const sandbox = {};
            vm.createContext(sandbox);
            
            // Хитрость: добавляем имя переменной в конец кода, 
            // чтобы vm.runInContext вернул её значение как результат
            const dataObj = vm.runInContext(code + '\n' + varName + ';', sandbox);

            if (dataObj && typeof dataObj === 'object') {
                let count = 0;
                for (const [id, item] of Object.entries(dataObj)) {
                    db.run(`
                        INSERT OR REPLACE INTO Components (id, category, name, image, desc, mcu, freq, mem, conn, code)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    `, [
                        id,
                        category,
                        item.name || '',
                        item.image || item.img || '',
                        item.description || item.desc || '',
                        item.mcu || '',
                        item.freq || '',
                        item.mem || '',
                        item.conn || '',
                        item.code || ''
                    ]);
                    count++;
                    totalAdded++;
                }
                console.log(`📥 Из ${file} добавлено ${count} компонентов.`);
            } else {
                console.log(`⚠️ В файле ${file} данные пустые.`);
            }
        } catch (err) {
            console.log(`❌ Ошибка при чтении ${file}: ${err.message}`);
        }
    });

    db.get("SELECT COUNT(*) as count FROM Components", (err, row) => {
        console.log(`\n🎉 Готово! Всего в базе: ${row.count} компонентов.`);
    });
});