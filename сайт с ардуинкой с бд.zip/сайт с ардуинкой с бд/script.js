document.addEventListener('DOMContentLoaded', () => {

    // === 0. ВНЕДРЕНИЕ МЯГКИХ СТИЛЕЙ И LIGHTBOX ===
    const softStyle = document.createElement('style');
    softStyle.textContent = `
        *, *:focus, *:focus-visible, *:active,
        a:focus, button:focus, summary:focus, input:focus, select:focus, textarea:focus {
            outline: none !important;
            -webkit-tap-highlight-color: transparent;
        }

        :root {
            --border-color: rgba(148, 163, 184, 0.22) !important;
        }
        body.dark-theme {
            --border-color: rgba(255, 255, 255, 0.07) !important;
        }

        .search-box, .calc-group input, .calc-group select {
            border: 1px solid var(--border-color) !important;
            transition: border-color 0.25s ease, box-shadow 0.25s ease, background-color 0.25s ease !important;
        }

        .search-box:focus, .calc-group input:focus, .calc-group select:focus {
            border-color: rgba(0, 137, 123, 0.45) !important;
            box-shadow: 0 0 0 4px rgba(0, 137, 123, 0.1) !important;
        }

        .category-tree details, .category-tree details[open],
        .stat-card, .about-section, .feature-card, .calc-card,
        .board-details, .board-image-wrapper, .spec-item, .back-home-btn {
            border-color: var(--border-color) !important;
        }

        .feature-card:hover {
            border-color: rgba(0, 137, 123, 0.35) !important;
        }

        .spec-item, .board-desc, .calc-result {
            border-left: 3px solid rgba(0, 137, 123, 0.55) !important;
        }

        #boardImage {
            cursor: zoom-in;
            transition: transform 0.25s ease, filter 0.25s ease;
        }
        #boardImage:hover {
            transform: scale(1.02);
            filter: drop-shadow(0 4px 12px rgba(0, 137, 123, 0.15));
        }

        .lightbox-overlay {
            position: fixed;
            inset: 0;
            background: rgba(11, 15, 25, 0.88);
            backdrop-filter: blur(6px);
            -webkit-backdrop-filter: blur(6px);
            z-index: 9999;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 2rem;
            opacity: 0;
            pointer-events: none;
            transition: opacity 0.25s ease;
            cursor: zoom-out;
        }
        .lightbox-overlay.active {
            opacity: 1;
            pointer-events: auto;
        }
        .lightbox-img {
            max-width: 92vw;
            max-height: 82vh;
            object-fit: contain;
            border-radius: 12px;
            background: #ffffff;
            padding: 1rem;
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.5);
            transform: scale(0.92);
            transition: transform 0.25s cubic-bezier(0.16, 1, 0.3, 1);
            cursor: default;
        }
        body.dark-theme .lightbox-img {
            background: #1f2937;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        .lightbox-overlay.active .lightbox-img {
            transform: scale(1);
        }
        .lightbox-caption {
            margin-top: 1rem;
            color: #f3f4f6;
            font-size: 1.05rem;
            font-weight: 600;
            text-align: center;
        }
        .lightbox-close {
            position: absolute;
            top: 20px;
            right: 28px;
            background: rgba(255, 255, 255, 0.12);
            color: #ffffff;
            border: none;
            width: 42px;
            height: 42px;
            border-radius: 50%;
            font-size: 1.5rem;
            line-height: 1;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: background 0.2s ease, transform 0.2s ease;
        }
        .lightbox-close:hover {
            background: rgba(255, 255, 255, 0.25);
            transform: scale(1.08);
        }

        .lang-toggle-btn {
            background: rgba(255, 255, 255, 0.2);
            border: none;
            color: #fff;
            padding: 6px 10px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 0.9rem;
            font-weight: 600;
            transition: background 0.2s;
            margin-left: 8px;
        }
        .lang-toggle-btn:hover {
            background: rgba(255, 255, 255, 0.35);
        }
    `;
    document.head.appendChild(softStyle);

    // === СОЗДАНИЕ LIGHTBOX В DOM ===
    const lightbox = document.createElement('div');
    lightbox.className = 'lightbox-overlay';
    lightbox.id = 'imageLightbox';
    lightbox.innerHTML = `
        <button type="button" class="lightbox-close" title="Закрыть (Esc)">×</button>
        <img class="lightbox-img" id="lightboxImg" src="" alt="Увеличенное фото">
        <div class="lightbox-caption" id="lightboxCaption"></div>
    `;
    document.body.appendChild(lightbox);

    const lightboxImg = document.getElementById('lightboxImg');
    const lightboxCaption = document.getElementById('lightboxCaption');

    function closeLightbox() {
        lightbox.classList.remove('active');
    }

    lightbox.addEventListener('click', (e) => {
        if (e.target !== lightboxImg) closeLightbox();
    });

    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && lightbox.classList.contains('active')) closeLightbox();
    });

    // === 1. СИСТЕМА ЛОКАЛИЗАЦИИ (РУС / ENG) ===
    const navEl = document.querySelector('header.site-header nav');
    let langToggleBtn = document.getElementById('langToggleBtn');
    
    if (!langToggleBtn && navEl) {
        langToggleBtn = document.createElement('button');
        langToggleBtn.type = 'button';
        langToggleBtn.id = 'langToggleBtn';
        langToggleBtn.className = 'lang-toggle-btn';
        navEl.appendChild(langToggleBtn);
    }

    let currentLang = localStorage.getItem('arduino_lang') || 'ru';

    const uiTranslations = {
        ru: {
            navHome: "Главная",
            navCatalog: "Справочник плат",
            navCalc: "🧮 Калькуляторы",
            navForum: "Форум сообщества",
            searchPlaceholder: "🔍 Поиск по всем разделам...",
            heroTitle: "Добро пожаловать в Arduino World",
            heroDesc: "Единая интерактивная энциклопедия для разработчиков электроники, робототехники, систем умного дома и 3D-принтеров. Больше не нужно искать даташиты по десяткам вкладок — всё собрано и структурировано в одном месте.",
            btnCatalog: "🚀 Открыть каталог (Uno R4)",
            btnCalc: "🧮 Инженерные калькуляторы",
            btnForum: "💬 Перейти на форум",
            stat1: "Модулей и плат в базе",
            stat2: "Интерактивных калькулятора",
            stat3: "Готовые примеры кода",
            stat4: "Живой форум инженеров",
            aboutTitle: "🎯 В чём суть проекта?",
            aboutDesc: "Arduino World создан как быстрый практический справочник для мейкеров, студентов и инженеров. Когда вы собираете устройство на микроконтроллере или настраиваете 3D-принтер, вам нужны точные параметры питания, распиновка, интерфейсы связи и рабочий шаблон кода для быстрого старта.",
            feat1Title: "Микроконтроллеры и SBC",
            feat1Desc: "Полные характеристики плат Arduino, ESP32/ESP8266, а также одноплатных компьютеров Raspberry Pi и Orange Pi.",
            feat2Title: "65+ Датчиков и сенсоров",
            feat2Desc: "От простых DHT22 и HC-SR04 до лазерных ToF-дальномеров, магнитных энкодеров AS5600, тепловизоров и газоанализаторов.",
            feat3Title: "ЧПУ и 3D-печать",
            feat3Desc: "Материнские платы BTT Octopus/Manta/SKR, шаговые двигатели серии NEMA, тихие драйверы TMC и готовые секции для Klipper/Marlin.",
            feat4Title: "Калькуляторы",
            feat4Desc: "Расчет резисторов для LED, закона Ома и шагов моторов на мм для 3D-принтеров и станков.",
            calcTitle: "🧮 Интерактивные калькуляторы инженера",
            backHome: "← На главную",
            calc1Title: "💡 Резистор для светодиода",
            calc1Desc: "Расчет номинала и мощности резистора для безопасного подключения светодиода.",
            calc2Title: "⚡ Закон Ома (U = I × R)",
            calc2Desc: "Расчет параметров цепи постоянного тока.",
            calc3Title: "⚙️ Шагов на мм (3D-печать)",
            calc3Desc: "Расчет шагов мотора для ремней и винтов.",
            codeTitle: "💻 Пример конфигурации / Код запуска:",
            copyBtn: "📋 Копировать код",
            copied: "✅ Скопировано!",
            sidebarLeftTitle: "🔌 Платы, контроллеры и датчики",
            sidebarRightTitle: "⚙️ Моторы, 3D-платы и драйверы",
            summaryArduino: "Платформа Arduino",
            summaryShields: "Шилды Arduino (Shields)",
            summaryEsp32: "Семейство ESP32",
            summaryEsp8266: "Семейство ESP8266",
            summaryEspShields: "Шилды ESP (ESP Shields)",
            summarySensors: "Датчики и сенсоры (Осн.)",
            summarySensorsPro: "Датчики (Спец. и Pro)",
            summaryRpi: "Raspberry Pi",
            summaryOrangePi: "Orange Pi",
            summaryNema: "Шаговые моторы NEMA",
            summaryPrinters: "Платы 3D-принтеров (CNC)",
            summaryDrivers: "Драйверы шаговых моторов",
            summaryServo: "Сервоприводы (Servo)"
        },
        en: {
            navHome: "Home",
            navCatalog: "Boards Guide",
            navCalc: "🧮 Calculators",
            navForum: "Community Forum",
            searchPlaceholder: "🔍 Search all categories...",
            heroTitle: "Welcome to Arduino World",
            heroDesc: "A unified interactive encyclopedia for electronics, robotics, smart home, and 3D printing developers. No more searching datasheets across dozens of tabs — everything is structured in one place.",
            btnCatalog: "🚀 Open Catalog (Uno R4)",
            btnCalc: "🧮 Engineering Calculators",
            btnForum: "💬 Visit Forum",
            stat1: "Modules & boards in base",
            stat2: "Interactive calculators",
            stat3: "Ready code examples",
            stat4: "Live engineer forum",
            aboutTitle: "🎯 What is this project about?",
            aboutDesc: "Arduino World is built as a quick practical reference for makers, students, and engineers. When building a microcontroller device or setting up a 3D printer, you need precise power specs, pinouts, communication interfaces, and a working code template for a fast start.",
            feat1Title: "Microcontrollers & SBC",
            feat1Desc: "Full specifications of Arduino, ESP32/ESP8266 boards, plus Raspberry Pi and Orange Pi single-board computers.",
            feat2Title: "65+ Sensors & Modules",
            feat2Desc: "From simple DHT22 and HC-SR04 to laser ToF sensors, AS5600 magnetic encoders, thermal cameras, and gas analyzers.",
            feat3Title: "CNC & 3D Printing",
            feat3Desc: "BTT Octopus/Manta/SKR motherboards, NEMA stepper motors, quiet TMC drivers, and ready sections for Klipper/Marlin.",
            feat4Title: "Calculators",
            feat4Desc: "Calculate LED resistors, Ohm's law, and steps per mm for 3D printers and CNC machines.",
            calcTitle: "🧮 Interactive Engineering Calculators",
            backHome: "← Back to Home",
            calc1Title: "💡 LED Resistor",
            calc1Desc: "Calculate resistor value and power rating for safe LED connection.",
            calc2Title: "⚡ Ohm's Law (U = I × R)",
            calc2Desc: "Calculate DC circuit parameters.",
            calc3Title: "⚙️ Steps per mm (3D Printing)",
            calc3Desc: "Calculate motor steps for belts and leadscrews.",
            codeTitle: "💻 Configuration Example / Startup Code:",
            copyBtn: "📋 Copy Code",
            copied: "✅ Copied!",
            sidebarLeftTitle: "🔌 Boards, Controllers & Sensors",
            sidebarRightTitle: "⚙️ Motors, 3D Boards & Drivers",
            summaryArduino: "Arduino Platform",
            summaryShields: "Arduino Shields",
            summaryEsp32: "ESP32 Family",
            summaryEsp8266: "ESP8266 Family",
            summaryEspShields: "ESP Shields",
            summarySensors: "Sensors (Basic)",
            summarySensorsPro: "Sensors (Special & Pro)",
            summaryRpi: "Raspberry Pi",
            summaryOrangePi: "Orange Pi",
            summaryNema: "NEMA Stepper Motors",
            summaryPrinters: "3D Printer Boards (CNC)",
            summaryDrivers: "Stepper Motor Drivers",
            summaryServo: "Servos"
        }
    };

    function applyLanguage(lang) {
        currentLang = lang;
        document.documentElement.lang = lang;
        localStorage.setItem('arduino_lang', lang);
        if (langToggleBtn) langToggleBtn.textContent = lang === 'ru' ? 'EN 🇬🇧' : 'RU 🇷🇺';

        const t = uiTranslations[lang];

        const nH = document.getElementById('navHome'); if(nH) nH.textContent = t.navHome;
        const nC = document.getElementById('navCatalog'); if(nC) nC.textContent = t.navCatalog;
        const nCalculators = document.getElementById('navCalculators'); if(nCalculators) nCalculators.textContent = t.navCalc;
        const nF = document.querySelector('header.site-header nav a[href*="forum"]'); if(nF) nF.textContent = t.navForum;
        
        const sBox = document.getElementById('categorySearch'); if(sBox) sBox.placeholder = t.searchPlaceholder;

        const hTitle = document.querySelector('.home-hero h1'); if(hTitle) hTitle.textContent = t.heroTitle;
        const hDesc = document.querySelector('.home-hero p'); if(hDesc) hDesc.textContent = t.heroDesc;
        const bCat = document.querySelector('[data-quick-board="uno-r4"]'); if(bCat) bCat.innerHTML = t.btnCatalog;
        const bCalc = document.getElementById('toCalculatorsBtn'); if(bCalc) bCalc.innerHTML = t.btnCalc;
        const bFor = document.querySelector('.home-hero a[href*="forum"]'); if(bFor) bFor.innerHTML = t.btnForum;

        const aTitle = document.querySelector('.about-section h2'); if(aTitle) aTitle.textContent = t.aboutTitle;
        const aDesc = document.querySelector('.about-section > p'); if(aDesc) aDesc.textContent = t.aboutDesc;

        const sLeft = document.querySelector('.sidebar-left h3'); if(sLeft) sLeft.textContent = t.sidebarLeftTitle;
        const sRight = document.querySelector('.sidebar-right h3'); if(sRight) sRight.textContent = t.sidebarRightTitle;

        const summaries = document.querySelectorAll('.category-tree summary');
        summaries.forEach(sum => {
            const txt = sum.textContent.trim();
            if (txt.includes("Arduino") && !txt.includes("Шилды")) sum.textContent = t.summaryArduino;
            else if (txt.includes("Шилды Arduino")) sum.textContent = t.summaryShields;
            else if (txt.includes("ESP32")) sum.textContent = t.summaryEsp32;
            else if (txt.includes("ESP8266")) sum.textContent = t.summaryEsp8266;
            else if (txt.includes("Шилды ESP")) sum.textContent = t.summaryEspShields;
            else if (txt.includes("Датчики и сенсоры (Осн.)")) sum.textContent = t.summarySensors;
            else if (txt.includes("Датчики (Спец. и Pro)")) sum.textContent = t.summarySensorsPro;
            else if (txt.includes("Raspberry Pi")) sum.textContent = t.summaryRpi;
            else if (txt.includes("Orange Pi")) sum.textContent = t.summaryOrangePi;
            else if (txt.includes("Шаговые моторы NEMA")) sum.textContent = t.summaryNema;
            else if (txt.includes("Платы 3D-принтеров")) sum.textContent = t.summaryPrinters;
            else if (txt.includes("Драйверы шаговых моторов")) sum.textContent = t.summaryDrivers;
            else if (txt.includes("Сервоприводы")) sum.textContent = t.summaryServo;
        });

        const cCalc = document.getElementById('calculatorsView');
        if (cCalc) {
            const calcHeader = cCalc.querySelector('h2'); if(calcHeader) calcHeader.textContent = t.calcTitle;
            const backBtns = cCalc.querySelectorAll('.back-home-btn');
            backBtns.forEach(btn => btn.textContent = t.backHome);
        }

        // Автоматически перерисовываем открытую вкладку при смене языка
        const boardDetailsView = document.getElementById('boardDetails');
        if (boardDetailsView && boardDetailsView.style.display === 'block') {
            window.openBoard(lastSelectedBoard);
        }
    }

    if (langToggleBtn) {
        langToggleBtn.addEventListener('click', () => {
            applyLanguage(currentLang === 'ru' ? 'en' : 'ru');
        });
    }

    applyLanguage(currentLang);

    // === 2. ТЕМНАЯ ТЕМА (DARK MODE) ===
    const themeToggleBtn = document.getElementById('themeToggleBtn');
    const savedTheme = localStorage.getItem('arduino_theme');

    if (savedTheme === 'dark') {
        document.body.classList.add('dark-theme');
        if (themeToggleBtn) themeToggleBtn.textContent = '☀️';
    }

    if (themeToggleBtn) {
        themeToggleBtn.addEventListener('click', () => {
            document.body.classList.toggle('dark-theme');
            const isDark = document.body.classList.contains('dark-theme');
            themeToggleBtn.textContent = isDark ? '☀️' : '🌙';
            localStorage.setItem('arduino_theme', isDark ? 'dark' : 'light');
        });
    }

    // === 3. УПРАВЛЕНИЕ РАЗДЕЛАМИ ===
    const homeView = document.getElementById('homeView');
    const boardDetails = document.getElementById('boardDetails');
    const calculatorsView = document.getElementById('calculatorsView');

    const navHome = document.getElementById('navHome');
    const navCatalog = document.getElementById('navCatalog');
    const navCalculators = document.getElementById('navCalculators');

    let lastSelectedBoard = 'uno-r4';

    function hideAllViews() {
        if (homeView) homeView.style.setProperty('display', 'none', 'important');
        if (boardDetails) boardDetails.style.setProperty('display', 'none', 'important');
        if (calculatorsView) calculatorsView.style.setProperty('display', 'none', 'important');
    }

    window.openHome = function() {
        hideAllViews();
        if (homeView) {
            homeView.style.setProperty('display', 'block', 'important');
            homeView.classList.remove('fade-animate');
            void homeView.offsetWidth;
            homeView.classList.add('fade-animate');
        }
        if (navHome) navHome.classList.add('active');
        if (navCatalog) navCatalog.classList.remove('active');
        if (navCalculators) navCalculators.classList.remove('active');

        document.querySelectorAll('.category-tree a').forEach(a => a.classList.remove('active'));
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    window.openCalculators = function() {
        hideAllViews();
        if (calculatorsView) {
            calculatorsView.style.setProperty('display', 'block', 'important');
            calculatorsView.classList.remove('fade-animate');
            void calculatorsView.offsetWidth;
            calculatorsView.classList.add('fade-animate');
        }
        if (navHome) navHome.classList.remove('active');
        if (navCatalog) navCatalog.classList.remove('active');
        if (navCalculators) navCalculators.classList.add('active');

        document.querySelectorAll('.category-tree a').forEach(a => a.classList.remove('active'));
        window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    // === УНИВЕРСАЛЬНЫЙ АВТОПЕРЕВОДЧИК И ОЧИСТКА АРТЕФАКТОВ "with" ДЛЯ ВСЕХ РАЗДЕЛОВ ===
    function cleanAndTranslateDescription(text) {
        if (!text) return text;

        // 1. Очищаем текст от случайных артефактов "with"
        let cleaned = text
            .replaceAll("withегмента", "сегмента")
            .replaceAll("withтановку", "установку")
            .replaceAll("withключающим", "исключающим")
            .replaceAll("withя", "ся")
            .replaceAll("механичеwithки", "механически")
            .replaceAll("обеwithпечивает", "обеспечивает")
            .replaceAll("выwithокую", "высокую")
            .replaceAll("чаwithтоту", "частоту")
            .replaceAll("withложных", "сложных")
            .replaceAll("withлотами", "слотами")
            .replaceAll("незавиwithимые", "независимые")
            .replaceAll("оwithи", "оси")
            .replaceAll("Применяетwithя", "Применяется")
            .replaceAll("withтанках", "станках")
            .replaceAll("надёжноwithть", "надёжность")
            .replaceAll("удобwithтво", "удобство")
            .replaceAll("обwithлуживания", "обслуживания")
            .replaceAll("withнижают", "снижают")
            .replaceAll("риwithк", "риск")
            .replaceAll("withжечь", "сжечь")
            .replaceAll("with", "с");

        // 2. Если включен английский — переводим любые инженерные описания
        if (currentLang === 'en') {
            const globalDict = {
                "Инновационная плата от": "Innovative board from",
                "Флагманская плата управления 3D-принтерами и ЧПУ-системами от": "Flagship 3D printer and CNC control board from",
                "Плата премиум-сегмента от": "Premium segment board from",
                "на 10 драйверов с новым фирменным безопасным разъёмом EZ-driver": "featuring 10 drivers with a new proprietary safe EZ-driver connector",
                "исключающим неправильную установку драйверов (полярность и ориентация контролируются механически).": "preventing incorrect driver installation (polarity and orientation are mechanically controlled).",
                "со встроенным разъёмом для установки вычислительных модулей": "with a built-in slot for compute modules",
                "что позволяет запускать Klipper (хост + MCU) на одном стеке без внешнего одноплатника.": "allowing Klipper (host + MCU) to run on a single stack without an external SBC.",
                "Построена на": "Powered by",
                "поддерживает": "supports",
                "питание моторов до": "motor power up to",
                "Оснащена слотами для модулей": "Equipped with module slots for",
                "разъёмами для вентиляторов, нагревателей и LCD.": "fan, heater, and LCD connectors.",
                "Применяется в больших принтерах": "Used in large printers",
                "и станках.": "and CNC machines.",
                "Главное преимущество —": "Main advantage —",
                "компактность и меньшее количество проводов (нет отдельного Raspberry Pi).": "compactness and fewer wires (no separate Raspberry Pi).",
                "Недостаток —": "Disadvantage —",
                "при использовании CB1/CM4 нужно тщательно продумывать охлаждение, так как модуль греется.": "cooling must be carefully designed when using CB1/CM4 as the module heats up.",
                "Отличный выбор для тех, кто хочет собрать минималистичный, но мощный принтер.": "Great choice for those who want to build a minimalist yet powerful printer.",
                "Имеет": "Features",
                "слотов для драйверов шаговых двигателей": "stepper motor driver slots",
                "защищённые входы термисторов": "protected thermistor inputs",
                "поддержку питания моторных осей до": "motor rail voltage support up to",
                "и отдельное питание логики 5 В через USB.": "and separate 5V logic power via USB.",
                "что позволяет использовать Klipper с высокой частотой шагов и сложными кинематиками": "allowing Klipper to be used with high step rates and complex kinematics",
                "Оснащена": "Equipped with",
                "слотом SD-карты": "SD card slot",
                "выходами для вентиляторов, нагревателей и LCD-экранов.": "outputs for fans, heaters, and LCD screens.",
                "Требует качественного охлаждения MCU и драйверов под нагрузкой.": "Requires proper cooling of the MCU and drivers under heavy load.",
                "Ультратихий драйвер двухфазных шаговых двигателей с технологией": "Ultra-quiet two-phase stepper motor driver with",
                "технологией": "technology",
                "Поддерживает управление по UART для программной настройки тока и микрошага.": "Supports UART control for software configuration of current and microstepping.",
                "Популярный тихий драйвер с поддержкой функции": "Popular silent driver supporting",
                "(определение упора без физических концевиков)": "(sensorless homing without physical endstops)",
                "для снижения нагрева.": "for reduced heating.",
                "Датчик температуры и влажности": "Temperature and humidity sensor",
                "Ультразвуковой датчик расстояния": "Ultrasonic distance sensor",
                "Гироскоп и акселерометр": "Gyroscope and accelerometer",
                "Шаговый двигатель": "Stepper motor",
                "Рабочее напряжение": "Operating voltage",
                "Частота": "Frequency",
                "Интерфейс": "Interface",
                "Подключение": "Connection"
            };

            let translated = cleaned;
            for (let [ru, en] of Object.entries(globalDict)) {
                translated = translated.replaceAll(ru, en);
            }
            return translated;
        }

        return cleaned;
    }

    // === Запрос к SQLite (REST API) ===
    window.openBoard = async function(boardId) {
        lastSelectedBoard = boardId;
        hideAllViews();

        try {
            const response = await fetch(`http://localhost:3000/api/components/${boardId}`);
            if (!response.ok) {
                console.warn('Компонент не найден в БД:', boardId);
                return;
            }
            const data = await response.json();

            let boardName = data.name || 'Без названия';
            let boardDesc = data.desc || '';
            boardDesc = cleanAndTranslateDescription(boardDesc);

            const l1 = document.getElementById('labelSpec1');
            const l2 = document.getElementById('labelSpec2');
            const l3 = document.getElementById('labelSpec3');
            const l4 = document.getElementById('labelSpec4');

            if (currentLang === 'en') {
                if (l1) l1.textContent = "Microcontroller / Chip";
                if (l2) l2.textContent = "Voltage / Frequency";
                if (l3) l3.textContent = "Memory / Range";
                if (l4) l4.textContent = "Interface / Connection";
            } else {
                if (l1) l1.textContent = "Микроконтроллер / Чип";
                if (l2) l2.textContent = "Напряжение / Частота";
                if (l3) l3.textContent = "Память / Диапазон";
                if (l4) l4.textContent = "Интерфейс / Подключение";
            }

            const nameEl = document.getElementById('boardName');
            const imgEl = document.getElementById('boardImage');
            const imgWrapEl = document.getElementById('boardImageWrapper');
            const descEl = document.getElementById('boardDesc');
            const mcuEl = document.getElementById('specMcu');
            const freqEl = document.getElementById('specFreq');
            const memEl = document.getElementById('specMem');
            const connEl = document.getElementById('specConn');
            const codeEl = document.getElementById('codeExample');

            if (nameEl) nameEl.textContent = boardName;
            
            const imgSrc = data.image || '';
            if (imgEl) {
                imgEl.src = imgSrc;
                imgEl.style.display = imgSrc ? 'block' : 'none';
                imgEl.title = currentLang === 'en' ? 'Click to zoom' : 'Нажмите для увеличения';
            }
            if (imgWrapEl) imgWrapEl.style.display = imgSrc ? 'block' : 'none';

            if (descEl) {
                descEl.textContent = boardDesc;
                descEl.style.display = boardDesc ? 'block' : 'none';
            }

            if (mcuEl) mcuEl.textContent = data.mcu || '-';
            if (freqEl) freqEl.textContent = data.freq || '-';
            if (memEl) memEl.textContent = data.mem || '-';
            if (connEl) connEl.textContent = data.conn || '-';
            if (codeEl) codeEl.textContent = data.code || '// Пример кода отсутствует';

            const backBtn = document.getElementById('boardDetails').querySelector('.back-home-btn');
            if (backBtn) {
                backBtn.textContent = currentLang === 'en' ? '← Back to Home' : '← На главную';
            }

            const copyBtnEl = document.getElementById('copyCodeBtn');
            if (copyBtnEl) {
                copyBtnEl.textContent = currentLang === 'en' ? '📋 Copy Code' : '📋 Копировать код';
            }

            document.querySelectorAll('.category-tree a').forEach(a => {
                if (a.getAttribute('data-board') === boardId) {
                    a.classList.add('active');
                    const parentDetails = a.closest('details');
                    if (parentDetails) parentDetails.open = true;
                } else {
                    a.classList.remove('active');
                }
            });

            const navHome = document.getElementById('navHome');
            const navCalculators = document.getElementById('navCalculators');
            const navCatalog = document.getElementById('navCatalog');

            if (navHome) navHome.classList.remove('active');
            if (navCalculators) navCalculators.classList.remove('active');
            if (navCatalog) navCatalog.classList.add('active');

            const boardDetailsView = document.getElementById('boardDetails');
            if (boardDetailsView) {
                boardDetailsView.style.setProperty('display', 'block', 'important');
                boardDetailsView.classList.remove('fade-animate');
                void boardDetailsView.offsetWidth;
                boardDetailsView.classList.add('fade-animate');
            }

            window.scrollTo({ top: 0, behavior: 'smooth' });

        } catch (err) {
            console.error('Ошибка загрузки компонента с сервера:', err);
        }
    };

    // === 4. ЛОГИКА КАЛЬКУЛЯТОРОВ ===
    function calculateLED() {
        const vcc = parseFloat(document.getElementById('ledVcc')?.value) || 0;
        const vf = parseFloat(document.getElementById('ledVf')?.value) || 0;
        const mA = parseFloat(document.getElementById('led電流')?.value) || 0;
        const resEl = document.getElementById('ledResult');
        if (!resEl) return;

        if (mA <= 0 || vcc <= vf) {
            resEl.textContent = currentLang === 'en' ? 'Error: Check input data' : 'Ошибка: Проверьте входные данные';
            return;
        }
        const r = (vcc - vf) / (mA / 1000);
        const p = (vcc - vf) * (mA / 1000);
        resEl.textContent = currentLang === 'en' ? `Resistor: ${Math.round(r)} Ω (Power ≥ ${p.toFixed(2)} W)` : `Резистор: ${Math.round(r)} Ом (Мощность ≥ ${p.toFixed(2)} Вт)`;
    }

    function calculateOhm() {
        const u = parseFloat(document.getElementById('ohmU')?.value) || 0;
        const r = parseFloat(document.getElementById('ohmR')?.value) || 1;
        const resEl = document.getElementById('ohmResult');
        if (!resEl) return;

        const i = u / r;
        const p = u * i;
        resEl.innerHTML = currentLang === 'en' ? `Current (I): ${i.toFixed(3)} A (${(i * 1000).toFixed(1)} mA)<br>Power (P): ${p.toFixed(3)} W` : `Ток (I): ${i.toFixed(3)} A (${(i * 1000).toFixed(1)} мА)<br>Мощность (P): ${p.toFixed(3)} Вт`;
    }

    function calculateSteps() {
        const rev = parseFloat(document.getElementById('stepRev')?.value) || 200;
        const micro = parseFloat(document.getElementById('stepMicro')?.value) || 16;
        const mech = document.getElementById('stepMech')?.value;
        const resEl = document.getElementById('stepResult');
        if (!resEl) return;

        let mmPerRev = 4;
        if (mech === 'gt2_20') mmPerRev = 40;
        else if (mech === 'gt2_16') mmPerRev = 32;
        else if (mech === 't8_lead4') mmPerRev = 4;
        else if (mech === 't8_lead8') mmPerRev = 8;

        const stepsPerMm = (rev * micro) / mmPerRev;
        resEl.textContent = currentLang === 'en' ? `Result: ${stepsPerMm.toFixed(2)} steps/mm` : `Результат: ${stepsPerMm.toFixed(2)} шагов/мм`;
    }

    ['ledVcc', 'ledVf', 'led電流'].forEach(id => document.getElementById(id)?.addEventListener('input', calculateLED));
    ['ohmU', 'ohmR'].forEach(id => document.getElementById(id)?.addEventListener('input', calculateOhm));
    ['stepRev', 'stepMicro', 'stepMech'].forEach(id => {
        document.getElementById(id)?.addEventListener('input', calculateSteps);
        document.getElementById(id)?.addEventListener('change', calculateSteps);
    });

    calculateLED();
    calculateOhm();
    calculateSteps();

    // === 5. ЕДИНЫЙ ОБРАБОТЧИК КЛИКОВ ===
    document.addEventListener('click', function(e) {
        const boardImg = e.target.closest('#boardImage');
        if (boardImg && boardImg.getAttribute('src')) {
            e.preventDefault();
            lightboxImg.src = boardImg.getAttribute('src');
            const titleEl = document.getElementById('boardName');
            lightboxCaption.textContent = titleEl ? titleEl.textContent : '';
            lightbox.classList.add('active');
            return;
        }

        const boardLink = e.target.closest('[data-board]');
        if (boardLink) {
            e.preventDefault();
            window.openBoard(boardLink.getAttribute('data-board'));
            return;
        }

        const quickCard = e.target.closest('[data-quick-board]');
        if (quickCard) {
            e.preventDefault();
            window.openBoard(quickCard.getAttribute('data-quick-board'));
            return;
        }

        if (e.target.closest('#navHome') || e.target.closest('#logoHomeLink') || e.target.closest('#backToHomeBtn')) {
            e.preventDefault();
            window.openHome();
            return;
        }

        if (e.target.closest('#navCalculators') || e.target.closest('#toCalculatorsBtn') || e.target.closest('#cardGoCalc')) {
            e.preventDefault();
            window.openCalculators();
            return;
        }

        if (e.target.closest('#navCatalog')) {
            e.preventDefault();
            window.openBoard(lastSelectedBoard);
            return;
        }

        const copyBtn = e.target.closest('#copyCodeBtn');
        if (copyBtn) {
            e.preventDefault();
            const codeEl = document.getElementById('codeExample');
            if (codeEl && navigator.clipboard) {
                navigator.clipboard.writeText(codeEl.textContent).then(() => {
                    const oldText = copyBtn.textContent;
                    copyBtn.textContent = uiTranslations[currentLang].copied;
                    setTimeout(() => { copyBtn.textContent = oldText; }, 2000);
                });
            }
        }
    });

    // === 6. ПОИСК ПО САЙДБАРАМ ===
    const searchInput = document.getElementById('categorySearch');
    if (searchInput) {
        searchInput.addEventListener('input', function(e) {
            const term = e.target.value.toLowerCase().trim();
            document.querySelectorAll('.category-tree').forEach(tree => {
                tree.querySelectorAll('details').forEach(details => {
                    let hasVisible = false;
                    details.querySelectorAll('li').forEach(item => {
                        if (item.textContent.toLowerCase().includes(term)) {
                            item.style.display = '';
                            hasVisible = true;
                        } else {
                            item.style.display = 'none';
                        }
                    });
                    details.style.display = (term.length > 0 && !hasVisible) ? 'none' : '';
                    if (hasVisible && term.length > 0) details.open = true;
                });
            });
        });
    }
});