const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./arduino_world.db');

// Вспомогательные обёртки для удобной работы через async/await
const runQuery = (sql, params = []) =>
    new Promise((resolve, reject) => {
        db.run(sql, params, function (err) {
            if (err) reject(err);
            else resolve({ lastID: this.lastID, changes: this.changes });
        });
    });

const getQuery = (sql, params = []) =>
    new Promise((resolve, reject) => {
        db.get(sql, params, (err, row) => (err ? reject(err) : resolve(row)));
    });

const allQuery = (sql, params = []) =>
    new Promise((resolve, reject) => {
        db.all(sql, params, (err, rows) => (err ? reject(err) : resolve(rows)));
    });

// ==========================================
// ЧАСТЬ 1. CRUD-функции для таблицы Components
// ==========================================

// 1. CREATE / INSERT — добавление новой записи
async function createComponent(comp) {
    const sql = `
        INSERT OR REPLACE INTO Components (id, category, name, desc, mcu, freq, mem, conn, code)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;
    return runQuery(sql, [
        comp.id, comp.category, comp.name, comp.desc,
        comp.mcu, comp.freq, comp.mem, comp.conn, comp.code
    ]);
}

// 2. READ / SELECT — получение списка всех записей
async function getAllComponents() {
    return allQuery('SELECT id, category, name, mcu FROM Components');
}

// 3. READ / SELECT по ID — поиск одной записи по Primary Key
async function getComponentById(id) {
    return getQuery('SELECT * FROM Components WHERE id = ?', [id]);
}

// 4. UPDATE — обновление атрибутов конкретной записи (строго с WHERE id = ?)
async function updateComponent(id, newName, newFreq) {
    return runQuery('UPDATE Components SET name = ?, freq = ? WHERE id = ?', [newName, newFreq, id]);
}

// 5. DELETE — удаление конкретной записи (строго с WHERE id = ?)
async function deleteComponent(id) {
    return runQuery('DELETE FROM Components WHERE id = ?', [id]);
}

// ==========================================
// ЧАСТЬ 2. Операции со связанными сущностями
// ==========================================

// Подготовка таблицы Reviews и добавление тестовых отзывов
async function initReviewsTable() {
    await runQuery(`
        CREATE TABLE IF NOT EXISTS Reviews (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            component_id TEXT NOT NULL,
            author TEXT NOT NULL,
            rating INTEGER CHECK(rating BETWEEN 1 AND 5),
            comment TEXT,
            FOREIGN KEY (component_id) REFERENCES Components(id) ON DELETE CASCADE
        )
    `);
    await runQuery('DELETE FROM Reviews WHERE component_id = ?', ['uno-r4']);
    await runQuery(
        'INSERT INTO Reviews (component_id, author, rating, comment) VALUES (?, ?, ?, ?)',
        ['uno-r4', 'Алексей', 5, 'Отличная плата, встроенная LED-матрица супер!']
    );
    await runQuery(
        'INSERT INTO Reviews (component_id, author, rating, comment) VALUES (?, ?, ?, ?)',
        ['uno-r4', 'Мария', 4, 'Хорошая производительность, но греется при 12В.']
    );
}

// Вариант А (Связь «один-ко-многим»): компонент + все его отзывы
async function getComponentWithReviews(componentId) {
    const sql = `
        SELECT c.id, c.name, c.mcu, r.author, r.rating, r.comment
        FROM Components c
        LEFT JOIN Reviews r ON c.id = r.component_id
        WHERE c.id = ?
    `;
    return allQuery(sql, [componentId]);
}

// Вариант Б (Агрегация данных): количество компонентов в каждой категории
async function getCategoryStats() {
    const sql = `
        SELECT category, COUNT(*) AS total_count
        FROM Components
        GROUP BY category
        ORDER BY total_count DESC
    `;
    return allQuery(sql);
}

// ==========================================
// ДЕМОНСТРАЦИЯ РАБОТЫ ВСЕХ ФУНКЦИЙ (для скриншота)
// ==========================================
async function runDemo() {
    try {
        console.log('=== ЧАСТЬ 1: CRUD-ОПЕРАЦИИ ===\n');

        // 1. CREATE
        await createComponent({
            id: 'test-stm32',
            category: 'arduino',
            name: 'STM32 Blue Pill',
            desc: 'Отладочная плата на ARM Cortex-M3',
            mcu: 'STM32F103C8T6',
            freq: '72 МГц / 3.3В',
            mem: '64 КБ Flash / 20 КБ RAM',
            conn: 'USB, UART, I2C, SPI',
            code: 'void setup() {}'
        });
        console.log('1. [CREATE] Добавлен компонент: test-stm32');

        // 2. READ ALL
        const all = await getAllComponents();
        console.log(`2. [READ ALL] Всего компонентов в базе: ${all.length}`);

        // 3. READ BY ID
        const found = await getComponentById('test-stm32');
        console.log('3. [READ BY ID] Найден компонент:', found.name, '| MCU:', found.mcu);

        // 4. UPDATE
        const updated = await updateComponent('test-stm32', 'STM32F103 Blue Pill (Updated)', '72 МГц');
        const afterUpdate = await getComponentById('test-stm32');
        console.log(`4. [UPDATE] Изменено строк: ${updated.changes} | Новое имя: ${afterUpdate.name}`);

        // 5. DELETE
        const deleted = await deleteComponent('test-stm32');
        console.log(`5. [DELETE] Удалено строк: ${deleted.changes} (тестовая запись удалена)\n`);

        console.log('=== ЧАСТЬ 2: СВЯЗАННЫЕ СУЩНОСТИ И АГРЕГАЦИЯ ===\n');

        // Вариант А (JOIN)
        await initReviewsTable();
        const withReviews = await getComponentWithReviews('uno-r4');
        console.log('Вариант А [JOIN] Компонент и его отзывы:');
        console.table(withReviews);

        // Вариант Б (Агрегация)
        const stats = await getCategoryStats();
        console.log('Вариант Б [GROUP BY / COUNT] Количество компонентов по категориям:');
        console.table(stats);

    } catch (err) {
        console.error('Ошибка выполнения:', err.message);
    } finally {
        db.close();
    }
}

runDemo();