const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');
const path = require('path');
const os = require('os');

const app = express();
app.use(cors());

// Раздаём все файлы сайта (HTML, CSS, JS, форум)
app.use(express.static(__dirname));

// Главная страница по корневому адресу http://localhost:3000
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'arduino.html'));
});

const db = new sqlite3.Database(path.join(__dirname, 'arduino_world.db'), (err) => {
    if (err) console.error('❌ Ошибка подключения к БД:', err.message);
    else console.log('✅ База данных arduino_world.db подключена!');
});

// Безопасная нормализация категорий, чтобы шилды точно попадали в свои разделы
function normalizeCategory(cat) {
    if (!cat) return '';
    const s = String(cat).toLowerCase().trim();

    if (s.includes('esp') && s.includes('shield')) return 'esp_shields';
    if (s.includes('shield')) return 'arduino_shields';
    if (s.includes('arduino')) return 'arduino';
    if (s.includes('3d') || s.includes('cnc') || s.includes('board')) return 'boards3d';
    if (s.includes('driver')) return 'drivers';
    if (s.includes('esp32')) return 'esp32';
    if (s.includes('esp8266')) return 'esp8266';
    if (s.includes('nema')) return 'nema';
    if (s.includes('orange')) return 'orangepi';
    if (s.includes('rasp')) return 'raspberrypi';
    if (s.includes('servo')) return 'servo';
    if (s.includes('sensor')) return 'sensors';

    return s;
}

// Получить список всех компонентов для меню
app.get('/api/components', (req, res) => {
    db.all('SELECT id, category, name FROM Components', [], (err, rows) => {
        if (err) return res.status(500).json({ error: err.message });

        const result = rows.map(row => ({
            id: row.id,
            category: normalizeCategory(row.category),
            name: row.name
        }));

        res.json(result);
    });
});

// Получить полную информацию по одному компоненту
app.get('/api/components/:id', (req, res) => {
    db.get('SELECT * FROM Components WHERE id = ?', [req.params.id], (err, row) => {
        if (err) return res.status(500).json({ error: err.message });
        if (!row) return res.status(404).json({ error: 'Компонент не найден' });
        res.json(row);
    });
});

const PORT = 3000;
app.listen(PORT, '0.0.0.0', () => {
    const nets = os.networkInterfaces();
    let localIp = 'localhost';

    for (const name of Object.keys(nets)) {
        for (const net of nets[name]) {
            if (net.family === 'IPv4' && !net.internal) {
                localIp = net.address;
            }
        }
    }

    console.log('\n🚀 Сервер Arduino World запущен!');
    console.log(`💻 На этом ПК:      http://localhost:${PORT}`);
    console.log(`🌐 В локальной сети: http://${localIp}:${PORT}\n`);
});